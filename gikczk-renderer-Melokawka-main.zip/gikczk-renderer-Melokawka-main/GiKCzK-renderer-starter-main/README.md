

### Uwaga! Commitujemy po każdym zadaniu! Należy poprawnie skonfigurować pola username/email swojego klienta gita! 
#### Można skorzystać z: [Setting your username in Git](https://help.github.com/en/github/using-git/setting-your-username-in-git) oraz [Setting your commit email address in Git](https://help.github.com/en/github/setting-up-and-managing-your-github-user-account/setting-your-commit-email-address#setting-your-commit-email-address-in-git)

- [ ] [Laboratorium 02](LAB02.md): Algorytmy rasteryzacji linii
- [ ] [Laboratorium 03](LAB03.md): Wypełnianie trójkątów

